// Minimal CSV parser (handles commas; not quotes). Good enough for league stats.
function parseCSV(text){
  const lines = text.trim().split(/?
/);
  const headers = lines.shift().split(',').map(h=>h.trim());
  return lines.filter(Boolean).map(line=>{
    const cols = line.split(',');
    const obj = {};
    headers.forEach((h,i)=>obj[h]= (cols[i] ?? '').trim());
    return obj;
  });
}

let data = [];
let sortState = { col: 'BestScore', dir: 'desc' };

function fmtMoney(n){
  const v = Number(n);
  if (Number.isNaN(v)) return '—';
  return v.toFixed(2);
}
function fmtPct(n){
  const v = Number(n);
  if (Number.isNaN(v)) return '—';
  return (v*100).toFixed(1) + '%';
}

function render(rows){
  const tbody = document.querySelector('#leaderboard tbody');
  tbody.innerHTML = '';
  rows.forEach(r=>{
    const tr = document.createElement('tr');
    const net = Number(r.NetProfit);
    const netClass = Number.isFinite(net) ? (net>=0?'positive':'negative') : '';
    tr.innerHTML = `
      <td><a href="player.html?player=${encodeURIComponent(r.Player)}">${r.Player}</a></td>
      <td class="num">${r.Games}</td>
      <td class="num ${netClass}">${fmtMoney(r.NetProfit)}</td>
      <td class="num">${fmtPct(r.ROI)}</td>
      <td class="num">${fmtPct(r.WinRate)}</td>
      <td class="num">${Number(r.BestScore).toFixed(3)}</td>
      <td class="num">${r.Rank}</td>
    `;
    tbody.appendChild(tr);
  });
}

function sortRows(rows){
  const {col,dir} = sortState;
  const mult = dir==='asc'?1:-1;
  return [...rows].sort((a,b)=>{
    const A = a[col];
    const B = b[col];
    const nA = Number(A);
    const nB = Number(B);
    if (!Number.isNaN(nA) && !Number.isNaN(nB)) return (nA-nB)*mult;
    return String(A).localeCompare(String(B))*mult;
  });
}

function applyFilter(){
  const q = document.querySelector('#search').value.trim().toLowerCase();
  const filtered = q ? data.filter(r=>r.Player.toLowerCase().includes(q)) : data;
  render(sortRows(filtered));
}

async function init(){
  const res = await fetch('data/leaderboard.csv', {cache:'no-store'});
  const text = await res.text();
  data = parseCSV(text);

  // default sort: BestScore desc
  sortState = {col:'BestScore', dir:'desc'};
  render(sortRows(data));

  // clickable headers
  document.querySelectorAll('th[data-col]').forEach(th=>{
    th.addEventListener('click', ()=>{
      const c = th.dataset.col;
      if (sortState.col === c) sortState.dir = (sortState.dir==='desc'?'asc':'desc');
      else { sortState.col = c; sortState.dir = 'desc'; }
      applyFilter();
    });
  });

  document.querySelector('#search').addEventListener('input', applyFilter);

  document.querySelector('#updated').textContent = 'Updated: ' + new Date().toLocaleString();
}

init().catch(err=>{
  console.error(err);
  document.querySelector('#updated').textContent = 'Updated: (failed to load data)';
});
