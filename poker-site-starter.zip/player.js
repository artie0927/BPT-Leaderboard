function parseCSV(text){
  const lines = text.trim().split(/?
/);
  const headers = lines.shift().split(',').map(h=>h.trim());
  return lines.filter(Boolean).map(line=>{
    const cols = line.split(',');
    const obj = {};
    headers.forEach((h,i)=>obj[h]= (cols[i] ?? '').trim());
    return obj;
  });
}

function qs(name){
  const u = new URL(location.href);
  return u.searchParams.get(name);
}

function fmtMoney(n){
  const v = Number(n);
  if (Number.isNaN(v)) return '—';
  return v.toFixed(2);
}
function fmtPct(n){
  const v = Number(n);
  if (Number.isNaN(v)) return '—';
  return (v*100).toFixed(1) + '%';
}

async function init(){
  const player = qs('player') || '';
  document.querySelector('#title').textContent = `🎴 ${player}`;

  const [lbText, sesText] = await Promise.all([
    fetch('data/leaderboard.csv', {cache:'no-store'}).then(r=>r.text()),
    fetch('data/sessions.csv', {cache:'no-store'}).then(r=>r.text()),
  ]);

  const leaderboard = parseCSV(lbText);
  const sessionsAll = parseCSV(sesText);

  const row = leaderboard.find(r=>r.Player===player);
  const sessions = sessionsAll.filter(s=>s.Player===player)
    .map(s=>({
      Date: s.Date,
      BuyIn: Number(s.BuyIn),
      Winnings: Number(s.Winnings),
      Net: Number(s.Net),
      ROI: Number(s.ROI)
    }))
    .sort((a,b)=> new Date(a.Date)-new Date(b.Date));

  // KPI cards
  const kpis = document.querySelector('#kpis');
  const mk = (label, value, cls='')=>{
    const div=document.createElement('div');
    div.className='kpi';
    div.innerHTML=`<div class="label">${label}</div><div class="value ${cls}">${value}</div>`;
    return div;
  };

  if (row){
    const net = Number(row.NetProfit);
    kpis.appendChild(mk('Rank', row.Rank));
    kpis.appendChild(mk('Games', row.Games));
    kpis.appendChild(mk('Net Profit', fmtMoney(row.NetProfit), net>=0?'positive':'negative'));
    kpis.appendChild(mk('ROI', fmtPct(row.ROI)));
    kpis.appendChild(mk('Win Rate', fmtPct(row.WinRate)));
    kpis.appendChild(mk('Best Score', Number(row.BestScore).toFixed(3)));
  } else {
    kpis.appendChild(mk('Not found', 'Player not in leaderboard'));
  }

  // Session table
  const tbody = document.querySelector('#sessions tbody');
  tbody.innerHTML='';
  sessions.forEach(s=>{
    const cls = s.Net>=0?'positive':'negative';
    const tr=document.createElement('tr');
    tr.innerHTML = `
      <td>${s.Date}</td>
      <td class="num">${fmtMoney(s.BuyIn)}</td>
      <td class="num">${fmtMoney(s.Winnings)}</td>
      <td class="num ${cls}">${fmtMoney(s.Net)}</td>
      <td class="num">${fmtPct(s.ROI)}</td>
    `;
    tbody.appendChild(tr);
  });
}

init().catch(console.error);
